<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/specification-list/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/specification-list/specification-list.php';