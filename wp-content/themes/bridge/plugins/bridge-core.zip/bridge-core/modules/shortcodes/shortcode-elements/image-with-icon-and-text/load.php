<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/image-with-icon-and-text/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/image-with-icon-and-text/image-with-icon-and-text.php';